# Independent model review A — first pass

You are an independent reviewer, not an author. Read AGENTS.md and relevant design
before judging. This is operator-authorized parallel review under the active goal
all selected specifications reviewed/stabilized, no runtime implementation.
Current implementation scope is Kubernetes including discovery, GitLab and SQL.

Exact source: b5abe434fbb34dfd889303f19933a9bff9e2e23a.
Tree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-model-review-a-20260909
Scratch/TMPDIR: .local/model-closure-20260909 inside this tree.
Own session: specs-model-review-a-20260909.
Tracked source and planning are read-only. Acquire/heartbeat/release only your
lease through worktree hooks. No integration calls, full Rust build, helper
program, Python, source fix, commit or AEP mutation. Do not read other current
review reports or contact implementors for their verdicts. Use pinned ESS
/home/timo/beyond10x/connectors_v2/.local/toolchains/ess/0.20.0/bin/ess.

The original 48-source review intake was completed at 8a5cf563 with two final
semantic approvals at d1dc83f5. This fresh stage closes explicit missing persistent
ESS models. You must independently judge new semantics and actual model joins,
not adopt implementor green reports as approval.

First-pass scope is the integrated auth and artifact provenance delta from
8a5cf563fc717fd4b23e4dd7d470d0c967f39461: ess/domains/auth_bindings.yaml,
artifact_provenance.yaml, declarations/credentials/credential_evidence joins,
four auth contract owners, catalog §9's shared immutable artifact rules, plus
their joins to existing refresh, admission, service/operations and custody.
Read docs/evidence/model-auth-closure-20260909/ and core-model-closure-20260909/
for claimed verification, then check those claims against actual source.

Focus on selected identity qualification and existing-ID preservation;
private allocation versus public publication; logical profile versus immutable
revision; acquisition consumption/expiry/repair and uncertain acknowledgement;
custody valid-use/retirement/revocation and non-reuse; reference versus ownership
and retained-history consequences; no-child-material bindings; safe immutable
artifact reuse without index deletion ownership; actual source/curation coverage
and preserved strict readers. Use concrete conflicting traces or observations.
Unexecuted trusted-owner predicates are explicitly runtime obligations; do not
demand runtime implementation, but do flag missing *specification* decisions or
contradictions that leave the implementor two incompatible behaviors.

The discovery/route and audit units are still integrating elsewhere. The
Connection mediated_route field and final design §31 entity inventory are known
coordinator joins pending their real domains. This initial pass cannot approve
the complete model stage, and those acknowledged pending joins are not findings
by themselves. Do review the currently selected non-pinning/route prose for
cross-contract coherence. A final exact source will be supplied after integration
for remaining coverage and any correction recheck.

Validate/compile the actual current ESS root independently. Keep any small
targeted probes as labeled scratch fixtures; no invented runtime-conformance
claim, broad repeated test suite or model-specific executable helper. Preserve
the exact initial report as initial-review.md, with verdict approve or
needs-revision for this selected first-pass scope. Findings must be actionable
with stable MCA-01 etc ids, priority, exact path/line, counterexample and smallest
remedy. Include a findings fenced JSON array using file,line,category,severity,
verdict,origin,message; put stable id/priority in message. If none, use [].
State exact executed checks and limits separately from manual reasoning.
Send concrete findings as soon as established; final whole-stage approval waits
for the coordinator's final-source update. Release your own lease at handoff.
