# Discovery/configuration unit handoff

Tree: `/home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-model-discovery-20260909`
Branch: `specs/model-discovery-20260909`
Base: `8a5cf563fc717fd4b23e4dd7d470d0c967f39461`
Specification: `specification:core-model-closure-20260909`
Next owner: coordinator `/root`, for real auth joins, combined verification,
independent reviews and local commit. All changes remain uncommitted.

## Exact changed paths

- `ess/domains/discovery_state.yaml` (new)
- `ess/domains/discovery.yaml`
- `contracts/discovery/resources/v1alpha1/semantics.md`
- `contracts/discovery/mediated_route/v1alpha1/semantics.md`
- `contracts/discovery/composition.md`
- `docs/evidence/model-discovery-closure-20260909/verification.md` (new)

No writes outside the assigned tracked allocation. No runtime, Python,
provider calls, planning mutations, commits or full gate.

## Selections

Collection owns finite scope-qualified observation history; Open/Retired is its
administrative lifecycle. Observed/Stale/Withdrawn/Retired is the private row
lifecycle; Withdrawn has no positive reuse, and public states stay unchanged.
Publication snapshot/index and bounded latest receipt share that one owner and
atomic transaction. View retirement is separate from collection retirement;
current scope continuity allows another admitted scan/publication in the same
Open collection. Qualified epoch loss invalidates old identities, not only pages.
All physical retained records count toward 256 scopes/500 rows; original 300/600
second evidence/history limits and non-pinning children are explicit.

Connection embeds `Optional<connectors.discovery.MediatedRouteBinding>`;
its existing parent field remains canonical. Route coordinates are historical,
never a live row FK. Only route evidence advances under same-target CAS.
Credentialless admitted direct parents have no fabricated material-generation
identity; profiles must explicitly admit that absence. Composition remains an
immutable typed value referring to existing ServiceConfiguration identities.

## Exact unapplied coordinator patch

`.local/model-closure-20260909/coordinator-joins.patch`
SHA256 `ed39d1599a87adb2d8621e9c8c7be2c7032bd2a0a13c338ed63ed5c0c1069b68`

It registers discovery_state, replaces its source-relation placeholder with a
real reference to `connectors.auth_bindings.Connection`, and inserts the route
field in the sibling's actual auth source read at handoff. The patch applies
cleanly to the captured before-files (`git apply --check`). Registration may
need context adjustment alongside the coordinator's other new domains.
The actual auth source was read only; no stubs or sibling writes were made.

## Verification

Baseline ESS 0.20.0: validate pass (14 files), compile pass (11 entities).
Registered scratch unit: validate pass (15 files), compile twice pass;
byte-identical outputs with SHA256
`efad732d0a919f03492a5be08fa9d2cba554822324a40c798a581613f717e985`.
Existing 11 identity records unchanged; exactly two entities added. Compiled
single ownership edge and terminal withdrawal/retirement checks pass. Negative
child ownership carrier Integer refuses with `type_mismatch`/`ESS-ENTITY-002`.
Tracked `git diff --check` passes. Provider alias scan of both owned shared ESS
sources finds no matches. Twelve focused source/model cases are recorded in the
tracked verification note; they are not runtime tests.

Raw baseline/unit IR, negative diagnostic, scratch before/after coordinator joins
and patch are retained under this scratch directory. This is a unit check,
not combined auth/discovery validation or a full repository gate.

No unresolved selected ownership/lifecycle blocker. Real auth joins remain for
the coordinator. Trusted evidence, clocks, identity allocation, field assignment,
canonical equality, durable atomicity/CAS, finite cleanup and live port/config
resolution remain explicit implementation predicates, with no ESS proof claimed.
