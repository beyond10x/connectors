# Auth model unit handoff

Base: 8a5cf563fc717fd4b23e4dd7d470d0c967f39461.
Branch: specs/model-auth-20260909.
Tree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-model-closure-20260909.
Work is uncommitted; root owns integration, bot commit, review and lifecycle cleanup.

Changed: new ess/domains/auth_bindings.yaml; only the four allocated auth profile,
connection, acquisition and custody v1alpha1 semantics; evidence under
`docs/evidence/model-auth-closure-20260909/`.

Selected: immutable qualified profile records distinct from existing logical
profile_ref; Live/Revoked Connection lifecycle independent of readiness; private
binding allocation before initial capture/custody; Acquisition fixed target and
Pending→Completing→Completed with Failed/Expired terminal outcomes, one-use consumption
and conservative unknown-acknowledgement handling; scoped immutable custody records
with guarded valid-use/retention deletion. Four entities, no new accounts, tenant
ownership, public codecs or runtime implementation.

Exact coordinator patches:
- .local/model-closure-20260909/shared-joins.patch: register auth domain; add existing
  generation→Connection reference through unchanged String connection_ref; optional
  authored requires_auth value; stale owner comments. Apply against integration with
  its existing artifact changes retained. No refresh entity/field change needed.
- .local/model-closure-20260909/mediated-route-join.patch: add Optional of the agreed
  connectors.discovery.MediatedRouteBinding after that real declaration exists.
  Both patches passed git apply --check against this worker base/current auth file.

Verification is retained in docs/evidence/model-auth-closure-20260909/verification.md:
baseline 14 files/218 declarations; unit plus available joins 15 files/252 declarations;
eleven old identities/lifecycles/old field types and all old named types preserved;
repeat canonical IR and 266 generated schema artifacts byte-identical; two expected
negative fixtures refused. Sixteen manual semantic/model cases are separate from
actual runtime execution. No full Rust build/gate, provider calls or planning writes.

The tracked worker root intentionally has no new domain registration: root owns it.
All model checks used a copied real ESS root plus exact available joins, no stubs.
Coordinator must validate the integrated root and the new real route field, run the
combined boundary/gate and obtain two independent reviews. All owned source decisions
are selected; no concrete unresolved spec blocker remains in this unit.

Remaining UNMAPPED predicates are execution: owner/identity/field equality, truthful
acknowledgements, durable one-use/uniqueness, state-dependent field assignment,
current time/authority, custody byte capture/erasure and retention fences, generation
publication/revoke/final-dispatch atomicity, and private/public projection codecs.
