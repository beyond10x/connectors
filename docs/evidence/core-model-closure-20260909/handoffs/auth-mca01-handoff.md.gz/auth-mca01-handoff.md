# MCA-01 correction handoff

Base: 6cee258b34ae0c9e0b0a5de5a5ed7fd04e336e4e.
Branch: specs/model-auth-20260909.
Only tracked changes: ess/domains/auth_bindings.yaml (one optional existing-type
Connection field/comments), contracts/auth/connection/v1alpha1/semantics.md
(bounded baseline semantics/table), and new evidence under
`docs/evidence/model-auth-closure-20260909/correction-mca01/`.

Selected one optional baseline EvidenceSnapshot, at most six distinct applicable
material baseline check rows; exact operation checks retain their existing scope.
Generation/binding match, absence before initial publication/no-material modes,
current-fence installation, non-history replacement/retention and per-check reuse
limits are explicit. No new evidence owner or side store.

Validation over real scratch joins: 15 files valid; 252 declarations compile;
266 private schema artifacts generated. Exact canonical IR comparison to the same
unit at 6cee258 finds only the added Connection.baseline_evidence field. Initial
verification remains unchanged. See correction-mca01/addendum.md for eight manual
cases, tool logs and precise unexecuted owner predicates.

No shared-file patch is needed for this correction. Root can integrate this exact
auth-file/doc delta while retaining its mediated_route field and other concurrent
changes. Root performs combined validation and independent reviewer recheck.
No commit/tag/CHANGELOG or planning action taken by this worker. Own lease released
at handoff; root owns final commit, cleanup and publication decisions.
