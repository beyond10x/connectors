# datasource.logs/v1alpha1

- **Status:** proposed, not implemented.
- **Family:** datasources. Siblings: [records](../../records/v1alpha1/semantics.md), [series](../../series/v1alpha1/semantics.md), relational (in [service v1alpha1](../../../service/v1alpha1/semantics.md)).
- **Recorded:** 2026-09-08.

## 1. Identity

| Field | Value |
|---|---|
| Contract | `datasource.logs/v1alpha1` |
| Profiles | `logql-range` (Loki), `kubernetes-pod-logs`, `docker-container-logs` |
| Shared with records | provenance, completeness, cursor binding rules (`docs/design.md:434-446`); not the record page shape |

A log read returns a bounded observation of the provider's available logs, with explicit selection, order and truncation. Loki preserves native LogQL and returned stream labels. Pod/container logs retain their resource and tail selectors and provider delivery order; they do not acquire an absolute Loki time window merely by sharing a result family. A result proves neither archival retention, absence of late arrivals, a provider-wide snapshot nor continuity across provider rotation/restart.

Loki continuation pages one immutable retained observation. It never reissues a provider query with an adjusted timestamp edge. The selected provider API supplies neither occurrence identity nor a tie cursor; timestamp/text/label hashes cannot distinguish two genuine identical entries. A saturated provider response therefore ends with a truthful non-resumable partial result after its retained entries have been delivered. The [provider evidence record](../../../../docs/evidence/datasource-semantics-20260908/provider-evidence.md) identifies the exact sources and selection limits.

## 2. Old evidence and disposition

| Old surface | Source | Disposition |
|---|---|---|
| `loki-query-range`: one operation from the pinned Loki HTTP API spec; direct origin or Grafana-mediated | `../connectors/providers/loki.toml` | preserve as `logql-range` |
| Old Loki projection: ≤ 500 streams, ≤ 1,000 lines, line text cut at 8 KiB with `truncated` per line, deterministic pattern redaction with `redacted` flag, `result_type`, per-line `timestamp`, `labels`, `line`; overall `truncated` | `../connectors/crates/integration-monitoring/src/projection.rs`, `project_loki` | preserve the shape and bounds as first-profile defaults; redaction becomes a configurable host-side filter, not a contract promise (arbitrary text cannot be proven secret-free, old design 08 amendment) |
| `kubernetes.pod.logs`: `namespace`, `pod`, optional `container`, `tail_lines` 1–1000 default 200, `since_seconds` 1–86400; output `text`, `truncated`; 128 KiB bound; namespace grant is the containment | `../connectors/crates/integration-kubernetes/src/workloads.rs:1120-1145` | preserve as `kubernetes-pod-logs`; change output from one `text` blob to lines with timestamps (Kubernetes `timestamps=true`) |
| Loki tenant/header binding where applicable | `docs/design.md:500` | preserve as receiver-owned `http.extra_headers` configuration (§4.1), never caller input; the earlier `tenant_header` wording was a conceptual label, not a second supported key |
| Docker container logs | official Engine API v1.56 `ContainerLogs` and `ContainerAttach`, archived in the [restart evidence](../../../../docs/evidence/restart-visibility-20260908/provider-evidence.md) | finite logs with supported driver, inspected TTY/framing, since/until and tail; no follow |

The official Loki v3.7.0 HTTP reference defines an inclusive start and exclusive end. Its pinned LogCLI implementation refuses a batch entirely occupied by the retained timestamp overlap (`query.go:177–200`). The predecessor's small Loki OpenAPI is repository-authored evidence, not a vendor specification. Kubernetes v1.35.0 PodLogOptions supplies relative time/tail and RFC3339 timestamps; it does not declare a selectable upper bound or exact absolute interval. These protocol declarations do not prove conformance of a deployed provider, proxy or future decoder.

## 3. Types

Input, `logql-range`:

```json
{ "query": "{app=\"api\"} |= \"error\"", "start_unix_ns": "1788822000000000000", "end_unix_ns": "1788825600000000000", "direction": "backward", "limit": 200, "collection_limit": 1000, "max_line_bytes": 8192 }
```

Only query and start are required. Direction defaults to backward; limit and collection_limit default to 1,000; max_line_bytes defaults to 8,192. **limit is the public page size; collection_limit is the single provider query's entry cap.** Both are integers in 1–1,000 with limit <= collection_limit; max_line_bytes is an integer in 1–8,192. This explicit distinction permits small public pages while keeping total collection bounded.

Resume input is exactly `{"cursor":"opaque value"}`. Mixed initial/resume fields, explicit null aliases, unknown members, provider interval/step/since overrides and caller origin/route/header selectors are InvalidInput. Resume cannot change the original query, time window, page size or projection.

Input, `kubernetes-pod-logs`:

```json
{ "namespace": "x", "pod": "api-0", "container": "api", "since_seconds": 3600, "tail_lines": 200, "max_bytes": 131072 }
```

Namespace/pod and optional container are validated literal Kubernetes path components. Defaults: since_seconds=86,400, tail_lines=200, max_bytes=131,072. Integer bounds: 1–86,400, 1–1,000 and 1–131,072 respectively. An omitted container uses the provider's single-container default; ambiguity is a safe failure, never fan-out.

Input, `docker-container-logs`:

```json
{ "target": {"container_name":"/api"}, "streams": ["stdout", "stderr"], "since_unix_s": 1788822000, "until_unix_s": 1788825600, "tail_lines": 200, "max_bytes": 131072 }
```

Target is exactly `{container_id:<64 lowercase hex characters>}` or `{container_name:<exact canonical name beginning with />}`; short IDs and path/query expressions are invalid. Streams is a nonempty duplicate-free stdout/stderr subset, default both. Tail/byte defaults and bounds equal the pod profile. Since is required; until defaults once to the receiver's current whole epoch second. Times are nonnegative integers convertible to signed-64-bit nanoseconds, with since < until and difference <=86,400 seconds. A TTY target requires both streams because its provider output is combined. All profile inputs are closed; no follow, previous-container, TLS override or arbitrary provider options are accepted.

Output (all profiles):

```json
{
  "lines": [ { "timestamp_unix_ns": "1788825599000000000", "stream": { "app": "api" }, "line": "…", "line_truncated": false, "redacted": false, "source": null } ],
  "selection": { "kind": "loki-range", "start_unix_ns": "…", "end_unix_ns": "…", "direction": "backward" },
  "order": "timestamp-backward",
  "complete": false,
  "truncation": { "causes": ["provider_limit"], "occurrences_dropped": null, "stream_groups_dropped": null },
  "next_cursor": null,
  "provenance": { "instance": "…", "resource": "loki:…", "observed_at_unix_ms": 0, "source_revision": null }
}
```

| Field | Rule |
|---|---|
| `timestamp_unix_ns` | canonical decimal string; nullable only for pod/container lines without a valid representable provider timestamp. Conversion preserves actual source precision |
| `stream` | returned Loki labels; `{namespace,pod,container}` for pod logs (container may be null when omitted); `{container_id}` with resolved full Docker ID |
| `source` | stdout/stderr from non-TTY Docker framing; null for Loki, combined pod output and TTY output |
| `redacted` / `line_truncated` | required Boolean flags for configured redaction and UTF-8-safe line clipping, independently |
| `selection` / `order` | closed profile variants below; no fabricated universal window |
| `complete` | source exhaustion AND no omitted occurrences AND final retained page; line-content clipping is separate (§5) |
| `truncation` | all applicable causes, plus exact counts only where the total is known (§5) |
| `next_cursor` | Loki only, iff another retained offset exists; null at a terminal partial result even when unseen provider entries may remain |

Pod selection is `{kind:kubernetes-relative-tail,since_seconds,tail_lines}`. Docker selection is `{kind:docker-seconds-tail,since_unix_s,until_unix_s,tail_lines,streams}`. Both use order=provider; Loki uses timestamp-forward/backward. An output label changed by native LogQL is a value, not proof of an original selector or authority. Safe errors and byte accounting are in §5.

## 4. Rules

Current host principal, visible operation, source/connection, scope and applicable credential/route evidence are admitted before dispatch. Known revocation and current binding fences also govern publication and result disclosure. These are host ordering guarantees, not an atomic transaction with future provider permission changes. No stale-on-error, cross-principal cache reuse, live follow or automatic read redispatch is selected. F15 owns any later refresh/retry profile under its original shared budget.

### 4.1 Monitoring tenant-header configuration (E30)

For the proposed direct monitoring binding, the normative representation is a receiver-owned entry in `http.extra_headers`, for example `{"X-Scope-OrgID": "tenant-a"}` as shown in the [Grafana child configuration](../../../../docs/adapters/grafana.md#6-configuration-outline). `tenant_header` in the earlier evidence table meant this configured provider header; it is not an accepted alias or an additional configuration object. This is a proposed configuration extension: the current `HttpConfig` does not implement arbitrary extra headers, and no legacy file is claimed to have a working `tenant_header` key that can be migrated automatically.

The operator binds the provider tenant to a connection during configuration admission. Query input, caller headers, provider response data and adapter-built request headers cannot choose, append or override it. The host installs exactly the admitted header value at dispatch; configuration validation rejects duplicate header names ignoring ASCII case and conflicts with credential placement or transport-owned headers. Unsupported headers/configuration are refused rather than ignored. Changes require a new admitted configuration revision; cached results and continuations must not cross that revision. A provider tenant header is distinct from the caller's verified SaaS tenant/realm and is never evidence of application authority.

For a Grafana-mediated child, the parent route and its admitted Grafana datasource configuration own any downstream provider tenant binding. The child does not forward a caller-selectable or direct-binding `extra_headers` override through the proxy. A requested tenant binding that the admitted parent route cannot establish is refused, with no direct fallback.

Textual verification: (1) direct Loki configuration and the monitoring example use the same `http.extra_headers` entry; (2) a request supplying `tenant_header`, `extra_headers` or a differently cased tenant header does not alter the connection and is refused where the closed request/binding rejects it; (3) a mediated child cannot override the parent's downstream tenant. These are binding obligations, not executed HTTP tests or a claim of an implemented configuration schema.

### 4.2 Native LogQL scope

Configuration selects `query_scope.required_equalities`, a duplicate-free array of exact `{label,value}` pairs. Missing scope configuration is invalid; an explicitly admitted empty array means the entire configured provider tenant is allowed. Valid provider label names and nonempty required values avoid empty-label/missing-label ambiguity.

A reviewed parser conforming to Loki v3.7.0 must accept the complete native log-selector or log-pipeline expression and inspect every initial stream selector. Each must contain every required equality with the exact decoded label/value and equality operator. Extra matchers and native filters/parsers/formatters remain supported. A regex, text inside a string, a pipeline label filter or a rewritten output label cannot discharge an initial equality. Metric/sample syntax is not a log query: literal/vector expressions also implement the provider's LogSelectorExpr interface, so interface membership alone is insufficient. The selected root must actually be a stream selector or pipeline.

Parse failure, unsupported/non-log syntax or exceeding 16 KiB UTF-8, 4,096 syntax nodes or depth 64 is InvalidInput. A valid log query missing the required scope is Forbidden. Neither dispatches. The admitted original query bytes are URL-encoded and forwarded unchanged: no reserialization, injected filters, fixed-query substitute or remote parsing probe. A missing/unverified parser cannot advertise the scoped profile. The same predicate applies through mediation and to declared verification queries.

### 4.3 Loki collection and ordering

Input nanoseconds are canonical `0` or `[1-9][0-9]*`, at most 9,223,372,036,854,775,807. Reject signs, whitespace, leading zeroes, decimal/exponent forms and overflow. Resolve omitted end once from the trusted receiver clock; require start < end and checked end-start <=86,400,000,000,000. The single GET fixes both exact decimal times, direction, `limit=collection_limit` and JSON output. No provider default time or sampling interval is used. Start is inclusive and end exclusive in both directions.

Validate the entire bounded JSON response before publishing. Require successful status, resultType=streams, string labels, valid two-element timestamp/text tuples, in-window representable timestamps and provider order within each group. Reject duplicate JSON keys, missing result type, metric results, malformed entries, unsupported tuple extensions, wrong ordering/window and counts above collection_limit as Unavailable. No malformed-entry skipping or incomplete-JSON prefix may establish an observation. This selected plain Loki success format has no generic partial field; unknown warning/partial extensions must fail safely instead of being ignored.

Retain the first 500 provider stream groups in response order, counting all omitted groups and occurrences from the fully validated response. Groups with identical returned labels remain separate groups for this bound; native pipelines can make their labels equal. Flatten retained groups with private `(group ordinal,entry ordinal)` coordinates. Sort by timestamp in the requested direction; ties use ascending coordinates. Never deduplicate equal timestamp/labels/text, even after redaction or clipping. Coordinates identify positions in this captured observation only.

Apply any admitted deterministic redaction once, flag changes, and then take the longest UTF-8 prefix within max_line_bytes. Clipping shortens content, not the occurrence count. Intern group labels and retain the immutable resulting occurrences, index and original private context under the storage ceiling. If the whole observation cannot fit, return Unavailable before the first page; do not drop stored pieces while claiming complete continuation.

Provider exhaustion requires a complete successful validated response with fewer than collection_limit occurrences, no known partial execution, and a provider/proxy binding verified to honor that effective limit and surface incomplete execution. A hidden smaller limit invalidates this proof. Exact-cap responses remain conservative partial even if exactly that many source entries existed. A validated empty response can establish exhaustion under the same conditions. Stats and emitted page size cannot establish it.

### 4.4 Retained paging and current authority

The host's logical ReadCursorCachePort owns this bounded ephemeral observation and context; it is not another provider entity or discovery publication. Offset zero starts the initial page. A page is the longest consecutive slice fitting the fixed public limit and complete serialized response ceiling, including repeated labels, escaping, selection, cursor and provenance. Reserve sufficient cursor/envelope bytes when deciding the slice. If even metadata plus one occurrence cannot fit, refuse without a cursor. Only a verified empty observation yields an empty page; a nonterminal page is never empty.

A next cursor exists iff a later retained offset exists. It authenticates an unpredictable observation reference and offset, bound to instance, operation/profile/contract/projection revision, connection and configured provider authority/tenant, direct or mediated source and parent/route/credential/private fences, principal/tenant/scope/policy, exact query/window/direction, collection/page/line limits and redaction configuration. No credential, origin or private route locator is exposed in the opaque token. Current admission precedes disclosure of cursor validity and cached content; then every context coordinate must match. A cursor grants no authority.

Repeating an admitted cursor returns the same slice without provider I/O, with a strictly advancing next offset when present. All pages preserve the original provider observation time and source_revision:null. Each request has its own ordinary handling deadline but cannot extend the fixed observation expiry, at most 300 seconds from initial observation. Expiry, eviction, restart/key loss or changed context is StaleCursor after current admission; unavailable authority/cache infrastructure is Unavailable. Never regenerate a view, resolve a fresh now, query a different edge or fall back to direct access. A new initial read is a separate observation and may repeat or change entries.

Cross-request query caching remains disabled by default; the retained observation is the explicitly selected exception needed for its own continuation. Current known revocation and binding fences govern publication and disclosure, including every cached page. Successful earlier admission or unchanged query text cannot override them.

### 4.5 Pod and container reads

Pod admission checks configured namespace and the exact `(get,"","v1","pods",namespace,pod,"log")` target under the existing permission-evidence rules. Make one finite log GET with follow=false, previous=false, timestamps=true, selected container/sinceSeconds/tailLines and combined output. Omit provider limitBytes: the pinned API says it may return slightly fewer/more bytes and split the last line, so it does not prove exact exhaustion. Enforce max_bytes while consuming instead. Never send insecureSkipTLSVerifyBackend. SinceSeconds is relative to the provider's request-time clock and available pod history; no upper endpoint or portable exact absolute interval is promised. Do not invent a local absolute window or sort null-timestamp lines into one.

Docker first admits one bounded metadata inspect against the configured daemon and exact requested ID/name. It fixes the returned full ID, validates the exact name when requested, configured ID/name/label scope, supported logging driver and TTY mode. Candidate metadata lookup is separately admitted and may inspect an object that does not qualify for log retrieval; no log body or raw inspect/environment result is disclosed. Outside-scope candidates are Forbidden before the log GET. The subsequent GET uses the resolved full ID, never an alias; known replacement/revocation before dispatch or disclosure refuses the result. Name/label membership is the inspect observation, not an atomic guarantee against concurrent renaming/relabelling.

Docker sends timestamps=true, follow=false, finite tail, selected stdout/stderr and integer since/until. The v1.56 endpoint promises native since/before-until selection; the profile exposes that integer-second selector, not a Loki nanosecond interval or cursor. Returned timestamp precision does not strengthen selection precision. Non-TTY output uses the documented eight-byte multiplex framing with validated stream type/reserved bytes/length; TTY output is raw combined text. Inspect selects the decoder: the logs endpoint does not set Content-Type. Unsupported driver/framing is Unavailable, not empty success.

For both profiles, accumulate text in provider delivery order; frame boundaries are not line boundaries. Split on LF, preserve empty occurrences and an unterminated final line at clean EOF. Remove a valid RFC3339/RFC3339Nano prefix and its separating space; otherwise preserve the text and report a null timestamp. Keep at most tail_lines occurrences and 8 KiB per line after optional redaction. At a receiver byte cutoff retain only valid UTF-8, mark a partial last line truncated and report incomplete; never manufacture EOF. Malformed UTF-8 or protocol framing is Unavailable. These profiles return next_cursor:null; a tail/byte cap is terminal partial.

## 5. Limits and completeness

| Bound | Value | Source |
|---|---|---|
| Loki occurrences / stream groups | 1,000 / 500 per observation | selected from old projection |
| Line bytes | 8 KiB maximum after redaction, before result JSON escaping | old projection ceiling |
| Loki labels | <=128 labels/group, <=128 UTF-8 bytes/name, <=4 KiB/value and <=32 KiB serialized group; violation refuses, never clips labels | selected metadata bound |
| Loki provider response | independently <=4 MiB encoded entity and decoded/decompressed JSON; <=16 KiB headers | selected bounded full decode |
| Retained observation | <=4 MiB accounted storage including interned labels, occurrences/index and private context | selected ephemeral retention |
| Public response | <=4 MiB including all framing, escaping and cursor | ordinary service binding |
| Pod/container text | max_bytes <=128 KiB; additionally <=256 KiB encoded/decoded stream bytes including framing and <=4,096 Docker frames | selected transport ceilings |
| Docker inspect | <=1 MiB encoded and decoded response | selected metadata bound |
| Window / relative selector | <=24 h where declared in the selected input | selected profile ceiling |
| Provider work | Loki/pod: one log GET; Docker: one inspect + one log GET; no retry/follow | selected call budget |
| Deadline | existing 20 s outer / 15 s shared provider budget; inspect and log GET share it | ordinary service binding |
| Cursor TTL | <=300 s from the original observation, never renewed by pages | selected retention |

These are receiver ceilings, not vendor defaults or measured throughput. Finite reads/cancellation do not prove immediate remote cancellation or bound a provider's internal scan/CPU work. Deployment-side query limits remain independently admitted requirements.

`complete = source_exhausted AND no_occurrences_omitted AND final_retained_page`. Line clipping is separate and may coexist with complete:true. For pod/container reads, a clean full response below the requested tail and receiver byte caps, with no provider partial signal or local omission, establishes exhaustion of the selected available history. Hitting either cap remains conservative partial. Interrupted/unknown EOF proves no exhaustion.

Truncation causes are duplicate-free in this order: provider_limit, provider_partial, stream_limit, page_limit, response_bytes, source_bytes, line_bytes. Record every applicable cause: provider_limit means saturated Loki collection or pod/container tail; stream_limit means omitted groups; page_limit/response_bytes explain a retained remainder; source_bytes means a valid bounded streaming cutoff; line_bytes means clipping on this page. Provider_partial requires an explicitly supported partial indication; an unknown extension refuses. Retained remainders are not dropped occurrences. A terminal incomplete observation may have no cursor while provider_limit/stream_limit persists.

Occurrences_dropped and stream_groups_dropped are exact nonnegative totals only when fully observed evidence establishes them, otherwise null for each affected total. Provider saturation leaves unseen totals unknown, not zero; an exact local omission count is not the total including unknown provider losses. Line clipping alone drops zero occurrences. Redaction has its own flag and does not guarantee secret-free content.

Safe base errors apply. Provider 400 for an admitted native query is InvalidInput without raw provider text. Deadline expiry before dispatch is Timeout; failed, malformed, oversized or interrupted provider observation is Unavailable unless the explicit streaming byte-cutoff rule establishes a valid partial result. No raw provider errors, query text, origins or credentials enter ordinary diagnostics.

## 6. Conformance scenarios (`docs/design.md:988`)

- 1,001 occurrences at timestamp T, collection_limit=1,000 and public limit=200: retain every returned occurrence including identical lines, deliver five pages, finish incomplete with no cursor and unknown unseen totals. No timestamp-edge query follows.
- 999 source occurrences under collection_limit=1,000 and public limit=200: four full pages and one 199-entry page; only the final page is complete when nothing was omitted. Repeating a cursor returns its identical slice.
- Exact-cap source is conservatively partial; validated empty source can be complete. A provider returning 1,800 entries against a requested cap of 1,000 is a protocol failure, not a basis for promising recovery of 800 unseen entries.
- 501 fully observed groups below the occurrence cap: preserve 500 groups, count known omissions, report stream_limit and final incomplete. Byte/page/line/provider causes accumulate without relabeling unknown losses as zero.
- Fixture line of 20 KiB → `line_truncated: true`, `line` is an 8 KiB UTF-8-safe prefix.
- Window exceeding the maximum → `InvalidInput`, no dispatch.
- Loki 400 (bad LogQL) → `InvalidInput`; the error message contains no provider body text.
- Kubernetes fixture for namespace outside allowlist → `Forbidden`, zero requests.
- Kubernetes fixture with `timestamps=true` lines → each line has a ns timestamp; a line without a timestamp is reported with `timestamp_unix_ns: null` rather than invented.
- Tenant header configured → present on the fixture request; caller input cannot set or override it.
- Required equality appears only in quoted line text, regex or a pipeline filter → scope refusal before dispatch. A native admitted selector/pipeline remains byte-for-byte unchanged.
- Metric result, missing type, malformed tuple, wrong window/order, oversized JSON or hidden lower provider cap cannot become complete empty logs.
- Expiry, eviction, policy/credential/parent-route/redaction changes or key loss refuse cursor reuse without a requery. A denied caller learns no private cursor status.
- Pod missing timestamps remain null in provider order; tail/byte cutoffs have no cursor. Docker TTY/framed output, unsupported driver, partial frame and name/label changes follow §4.5.

These are specification scenarios, not implemented fixture results. Detailed dispositions and executable shape evidence must record their actual verification boundary; ESS shape acceptance does not execute provider, ordering or authority decisions.

## 7. Compatibility

- New contract; no old wire contract for logs existed beyond operation results. The old `kubernetes.pod.logs` `text` blob is not preserved; a facade may join lines.
- [Service compatibility](../../../service/compatibility.md) is authoritative for the binding. Log schemas can inhabit the ordinary result slot, but require explicit profile support; framing compatibility does not confer log or cursor semantics on existing typed consumers. Tenant headers remain receiver configuration.


## 8. SDK and host obligations

| Obligation | Where |
|---|---|
| `LogLine`, `LogRead` types | `crates/connectors-contracts/src/lib.rs` |
| Immutable observation retention and admitted offset cursor | future SDK/host binding; the existing `crates/connectors-sdk/src/lib.rs:161` helper authenticates a token but proves neither retention, progress, exhaustion nor scope |
| Native LogQL admission, bounded decoders and current disclosure fences | future adapter/host binding; no implementation provided by this contract |
| Receiver-owned `http.extra_headers` placement and validation (§4.1) | future `HttpConfig` / `HttpCapability` binding; current host configuration does not implement this extension |

## 9. ESS entities

LogQL range selection, direction and required selector equalities are typed in the
[Loki-owned model](../../../adapters/loki/ess/domains/reads.yaml). They are not
universal inputs for pod/container streams. Shared collection/page facts and
decisions remain in `ess/domains/datasource_reads.yaml`; adapter predicates and
runtime enforcement are not supplied by these private shapes.

| Entity / value | Notes |
|---|---|
| `OperationDeclaration.profile` in `{logql-range, kubernetes-pod-logs, docker-container-logs}` | value |
| Streams, lines | not entities; payload |

Proposed provider-independent collection/page facts and completeness decisions belong in `ess/domains/datasource_reads.yaml`; native selections remain adapter-owned as above. Provider grammar, full context equality, occurrence preservation/order, decoding, clocks, numeric/byte bounds and atomic current publication remain explicitly UNMAPPED binding obligations. No persistent provider entity, parser, public codec or cache implementation is introduced.

## 10. Open decisions

| Decision | Default taken |
|---|---|
| Redaction | host filter, opt-in, flagged per line; not a contract guarantee |
| Window maximum | 24 h |
| Docker `until` support | selected from official v1.56 integer-second API; provider-native selector, no nanosecond continuation claim |
| Durable/archival continuation and live follow | separate unselected profiles; finite native queries and retained Loki paging remain selected |
