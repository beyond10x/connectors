# Adapter-owned semantic models

The root `ess/` describes shared Connectors behavior. Provider names, provider
catalogs, native resource coordinates, representation enums and recognizer rules
belong in the owning adapter's specification. A provider-specific structure stays
typed here; replacing its name with a generic name does not make it shared.

These are independent, proposed ESS models under `<owner>/ess/`, with namespaces
`connectors_<owner>.<domain>`. They add no provider runtime, adapter-kind fields or
public codecs. Existing generated adapter specifications under `adapters/` keep
their own ownership and generation workflow. Shared ESS neither includes these
roots nor references their types. Each root validates and compiles independently;
the explicit adapter projection into shared facts/references remains a binding
obligation, not an ESS cross-root import or an arbitrary JSON payload bag.

| Owner | Typed semantics |
|---|---|
| [Atlassian](atlassian/ess/domains/documents.yaml) | Document representations and space/project scope kinds |
| [Docker](docker/ess/domains/mutations.yaml) | Container lifecycle action and exact resolved intent |
| [Kubernetes discovery](kubernetes/ess/domains/discovery.yaml) | Fixed profile, recognized providers, recognizer inputs and partition coordinates |
| [Kubernetes mutations](kubernetes/ess/domains/mutations.yaml) | Conditional Deployment target and prepared restart marker |
| [Kubernetes permissions](kubernetes/ess/domains/permissions.yaml) | Exact seven-field authorization target tuple |
| [Grafana](grafana/ess/domains/discovery.yaml) | Fixed discovery profile, recognized datasource providers and collection partition kind |
| [Loki](loki/ess/domains/reads.yaml) | LogQL range selection, direction and mandatory selector equalities |

Shared values retain admission, outcomes, coverage state and budgets. Profile,
provider and partition-kind strings are opaque identifiers whose admitted values
are fixed by the adapter. Shared permission targets contain private binding/target
references: adapters own canonical target equality and map their typed targets to
these references. Public permission tuples and discovery partition metadata keep
their selected profile codecs; shared private references are not wire replacements.
The root model intentionally does not enumerate the installed provider universe.

The repository gate runs the same check as:

```sh
TMPDIR="$PWD/.local/tmp" CARGO_BUILD_JOBS=2 cargo run --locked --offline -p connectors-build -- ess-boundary
```

It scans every file beneath `ess/`, including paths, comments and decoded YAML
keys/scalars. [The reviewed terminology policy](../ess-boundary.json) includes
provider aliases and native concepts that previously leaked without a brand name.
Names from every `adapters/*/spec/adapter.json` and every authored adapter-model
directory are added automatically. There are no per-file suppressions. Shared
references to adapter source paths, symlinked model sources, foreign domain
namespaces, unloaded/nested YAML and manifest/source mismatches fail. ESS then
validates and compiles the shared root and every authored adapter root separately;
unresolved cross-root type dependencies fail the compiler.

HTTP, OAuth2, SIP and other shared protocol contracts remain legitimate shared
vocabulary. This lexical/structural gate cannot determine whether unfamiliar prose
or a newly invented generic-sounding type encodes provider-specific semantics.
Review new shared types and extend the policy when a new alias or native concept
is found. This check does not prove public codec or provider behavior, or lint the
historical review snapshots and provider-specific prose throughout `contracts/`.
