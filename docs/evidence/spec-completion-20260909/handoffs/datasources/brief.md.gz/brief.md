# Specification completion brief: datasources

story: story:contracts-log-continuation then story:contracts-document-admission
branch: specs/datasources-20260909
base: 8e1836cad8ae1b2127ce9ae306c6d8131960db4c
worktree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-datasources-20260909
build dir: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-datasources-20260909/target
scratch: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-datasources-20260909/.local/spec-completion-20260909
session: specs-datasources-implementor-20260909

## Assignment
Complete F12 (LD-A-01–03 / LD-B-01–04), then F14 (LD-A-04–08 / LD-B-05–08), sequentially as the sole native datasource owner. The existing drafts contain the principal corrections: finish scenario dispositions, remaining concrete consistency fixes and honest model/UNMAPPED evidence. Avoid restarting the design.
Yours:
- adapters/loki/contracts/logs/v1alpha1/**, adapters/loki/spec/ess/**, adapters/loki/design.md
- adapters/kubernetes/contracts/logs/v1alpha1/**
- adapters/docker/contracts/logs/v1alpha1/**
- adapters/atlassian/contracts/documents/v1alpha1/**, adapters/atlassian/spec/ess/**, adapters/atlassian/design.md
- New native evidence beneath these contract directories, including append-only provider-source archives/manifests.
Coordinator owns shared contracts/datasources/{logs,records}, ess/**, all shared auth/service, docs/design, root indexes and existing docs/evidence. Provide patches for required shared consistency fixes.
Read the initial datasource review records and current draft evidence. Specifically settle nullable Confluence PageBulk.subtype vs trusted query predicate, simultaneous truncation causes, CQL immutable lineage/page-state bounds, quoting example, stale relocated section references and full source-envelope accounting.
Primary read-only source cache permitted: /home/timo/beyond10x/connectors_v2/.local/datasource-semantics-20260908/provider/. Archive the missing Kubernetes types, Loki AST/parser and official CQL pages into NEW native evidence directories with exact original URL/source hash; update native citations to these records. This evidence task is now yours, not coordinator's; no Python or archive-intake. Do not copy unrelated .local data.
Separate checks from inferred provider semantics. No final independent review of your own work; coordinator dispatches it after handoff.

## Repository invariants
Read AGENTS.md, docs/design.md, your full story bodies and the applicable worktree/ESS skills before editing. The operator authorized parallel specification completion and local coordinator commits; old story language excluding ESS/commits is superseded by that authorization. Runtime implementation remains excluded.
- Acquire your own lease with worktree hook session-start --path YOUR_TREE --session YOUR_SESSION; heartbeat periodically and release only your own lease at handoff.
- Work only inside your assigned tree. No git add/commit/stash/branch/worktree commands. Coordinator handles integration and cleanup.
- No planning-store writes, aep mutation commands, Python, helper scripts, runtime/provider/codec implementation or external publication.
- Nothing under /tmp; TMPDIR is YOUR_TREE/.local/tmp. Never set CARGO_TARGET_DIR. Any Rust build uses only YOUR_TREE/target. No cargo fmt --all.
- Existing review reports and source snapshots are immutable. New evidence may be added under assigned paths; do not rewrite history.
- Use connectors for integrations, never fluxplane-plugin. Official-source gaps were reported; read-only official web research remains permitted where needed.
- The implementor charter's runtime test-first requirement is adapted to the user's specification-only goal: record concrete failing textual scenarios before correction, check them after correction, distinguish manual reasoning from executed ESS validation. Do not create runtime tests to manufacture counts.
- Give exact unapplied patches in scratch for coordinator-owned files. A shared-file need is neither permission to edit it nor a reason to leave it unresolved.

## Focused verification and handoff
Run git diff --check. Run pinned ESS specify/compile against affected roots using /home/timo/beyond10x/connectors_v2/.local/toolchains/ess/0.20.0/bin/ess (inspect help for syntax), outputs in your scratch. No cold full Rust build; integration runs the full gate once.
Report six header lines: unit, verdict, cases (manual scenarios and executed model checks distinguished), origin, wrote-outside-worktree, needs-coordinator. Include exact commands, exit statuses and summaries; source/finding dispositions; git diff --stat; new files; patch paths. Do not claim runtime conformance from schema or textual checks.
Use /home/timo/.codex/plugins/cache/beyond10x/aep-drive/0.8.1/agents/implementor.md as role guidance subject to these explicit adaptations. The harness exposes generic agents; this is a charter-based dispatch, not an engine-driven run.

