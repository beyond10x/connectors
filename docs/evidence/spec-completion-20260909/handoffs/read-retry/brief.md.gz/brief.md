# Specification completion brief: read-retry

story: story:contracts-read-refresh-retry
branch: specs/read-retry-20260909
base: 8e1836cad8ae1b2127ce9ae306c6d8131960db4c
worktree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-read-retry-20260909
build dir: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-read-retry-20260909/target
scratch: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-read-retry-20260909/.local/spec-completion-20260909
session: specs-read-retry-implementor-20260909

## Assignment
Resolve F15/E05 with the explicitly selected bounded read-refresh-once/v1alpha1 binding, retaining existing legacy no-retry behavior. Only directly admitted credential-bearing unary reads, explicit profile/projection selection on v1alpha2; no mutation/streaming/anonymous/static-config/mediated expansion. One definitive 401, at most one coordinated refresh participation and at most one redispatch, original deadline/authority/target/budget ledger, fresh generation dispatch admission.
Existing per-invocation permission slots remain consumed: no fresh target-call allowance after refresh. Fail closed if new-generation permission evidence is unavailable within remaining existing slots.
Yours:
- contracts/auth/capability/v1alpha1/read-refresh-once.md (new)
- contracts/auth/capability/v1alpha1/semantics.md
- contracts/auth/acquisition/v1alpha1/semantics.md
- contracts/service/v1alpha1/semantics.md
- docs/evidence/read-refresh-retry-20260909/**
Coordinator owns contracts/service/compatibility.md, contracts/service/v1alpha2/semantics.md, all indexes, docs/design, ESS and planning. Supply exact scratch patches for selection/compatibility references. Cleanup worker may request capability vocabulary edits; send those to coordinator for application after your result.
No existing adapter silently selects this new binding. Selection must be concrete enough for an adapter author to implement without inventing a wire field or inferred grant. Disposition future binding vs supported runtime explicitly. Reuse settled refresh/evidence models unless actual missing typed entity is proved; report needed ESS change instead of silently leaving it unmodeled.

## Repository invariants
Read AGENTS.md, docs/design.md, your full story bodies and the applicable worktree/ESS skills before editing. The operator authorized parallel specification completion and local coordinator commits; old story language excluding ESS/commits is superseded by that authorization. Runtime implementation remains excluded.
- Acquire your own lease with worktree hook session-start --path YOUR_TREE --session YOUR_SESSION; heartbeat periodically and release only your own lease at handoff.
- Work only inside your assigned tree. No git add/commit/stash/branch/worktree commands. Coordinator handles integration and cleanup.
- No planning-store writes, aep mutation commands, Python, helper scripts, runtime/provider/codec implementation or external publication.
- Nothing under /tmp; TMPDIR is YOUR_TREE/.local/tmp. Never set CARGO_TARGET_DIR. Any Rust build uses only YOUR_TREE/target. No cargo fmt --all.
- Existing review reports and source snapshots are immutable. New evidence may be added under assigned paths; do not rewrite history.
- Use connectors for integrations, never fluxplane-plugin. Official-source gaps were reported; read-only official web research remains permitted where needed.
- The implementor charter's runtime test-first requirement is adapted to the user's specification-only goal: record concrete failing textual scenarios before correction, check them after correction, distinguish manual reasoning from executed ESS validation. Do not create runtime tests to manufacture counts.
- Give exact unapplied patches in scratch for coordinator-owned files. A shared-file need is neither permission to edit it nor a reason to leave it unresolved.

## Focused verification and handoff
Run git diff --check. Run pinned ESS specify/compile against affected roots using /home/timo/beyond10x/connectors_v2/.local/toolchains/ess/0.20.0/bin/ess (inspect help for syntax), outputs in your scratch. No cold full Rust build; integration runs the full gate once.
Report six header lines: unit, verdict, cases (manual scenarios and executed model checks distinguished), origin, wrote-outside-worktree, needs-coordinator. Include exact commands, exit statuses and summaries; source/finding dispositions; git diff --stat; new files; patch paths. Do not claim runtime conformance from schema or textual checks.
Use /home/timo/.codex/plugins/cache/beyond10x/aep-drive/0.8.1/agents/implementor.md as role guidance subject to these explicit adaptations. The harness exposes generic agents; this is a charter-based dispatch, not an engine-driven run.

