# Specification completion brief: contract-cleanup

story: story:contracts-media-controls then story:contracts-supported-vocabulary; prepare story:contracts-documentation-index patch after media
branch: specs/contract-cleanup-20260909
base: 8e1836cad8ae1b2127ce9ae306c6d8131960db4c
worktree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-contract-cleanup-20260909
build dir: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-contract-cleanup-20260909/target
scratch: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-contract-cleanup-20260909/.local/spec-completion-20260909
session: specs-contract-cleanup-implementor-20260909

## Assignment
Finish E23/E24 media controls, then E27 vocabulary. Prepare the E22 dependency/index patch after media semantics are settled; coordinator records dependency closure and applies root index changes.
Yours:
- adapters/sip/design.md; adapters/sip/contracts/dial/v1alpha1/semantics.md
- adapters/rtvbp/design.md; adapters/rtvbp/contracts/session/v1alpha1/semantics.md
- docs/compositions/media-session.md
- contracts/media/v1alpha1/semantics.md
- contracts/auth/profile/v1alpha1/semantics.md
- adapters/prometheus/contracts/series/v1alpha1/semantics.md
- contracts/datasources/series/v1alpha1/semantics.md
- contracts/discovery/resources/v1alpha1/semantics.md
- docs/evidence/media-controls-20260909/**; docs/evidence/supported-vocabulary-20260909/**; docs/evidence/documentation-index-20260909/**
Coordinator owns contracts/auth/capability/v1alpha1/semantics.md (retry agent writing it), contracts/README.md, adapters/README.md, docs/design.md, contracts/sessions, all ESS and planning. Provide exact scratch patches, with dependency matrix sourced from actual declarations, for coordinator.
Clarify RTVBP atomic redemption belongs to inbound-verifier, not an eighth auth.evidence check. Classify close/signal/interrupt/offer/accept/reject as protocol messages unless an explicit independently admitted operation is declared; distinguish sip.dial and sip.sessions.list.
Give explicit supported/reserved-refused/removed disposition and rationale for http_signing, oauth2_password, hold/transfer, promql-instant/promql-labels and address locator. Preserve selected requirements; unsupported names cannot be advertised or selected. Reconcile SIP static_entry auth.acquisition plus Kube/Docker connection/custody, Grafana custody and media datasource.records dependencies.
Do not edit citations opportunistically beyond these source paths; coordinator owns E15/E16/E17/E18/E25/E26/E31/E33 audit and will serialize overlap patches after merge.

## Repository invariants
Read AGENTS.md, docs/design.md, your full story bodies and the applicable worktree/ESS skills before editing. The operator authorized parallel specification completion and local coordinator commits; old story language excluding ESS/commits is superseded by that authorization. Runtime implementation remains excluded.
- Acquire your own lease with worktree hook session-start --path YOUR_TREE --session YOUR_SESSION; heartbeat periodically and release only your own lease at handoff.
- Work only inside your assigned tree. No git add/commit/stash/branch/worktree commands. Coordinator handles integration and cleanup.
- No planning-store writes, aep mutation commands, Python, helper scripts, runtime/provider/codec implementation or external publication.
- Nothing under /tmp; TMPDIR is YOUR_TREE/.local/tmp. Never set CARGO_TARGET_DIR. Any Rust build uses only YOUR_TREE/target. No cargo fmt --all.
- Existing review reports and source snapshots are immutable. New evidence may be added under assigned paths; do not rewrite history.
- Use connectors for integrations, never fluxplane-plugin. Official-source gaps were reported; read-only official web research remains permitted where needed.
- The implementor charter's runtime test-first requirement is adapted to the user's specification-only goal: record concrete failing textual scenarios before correction, check them after correction, distinguish manual reasoning from executed ESS validation. Do not create runtime tests to manufacture counts.
- Give exact unapplied patches in scratch for coordinator-owned files. A shared-file need is neither permission to edit it nor a reason to leave it unresolved.

## Focused verification and handoff
Run git diff --check. Run pinned ESS specify/compile against affected roots using /home/timo/beyond10x/connectors_v2/.local/toolchains/ess/0.20.0/bin/ess (inspect help for syntax), outputs in your scratch. No cold full Rust build; integration runs the full gate once.
Report six header lines: unit, verdict, cases (manual scenarios and executed model checks distinguished), origin, wrote-outside-worktree, needs-coordinator. Include exact commands, exit statuses and summaries; source/finding dispositions; git diff --stat; new files; patch paths. Do not claim runtime conformance from schema or textual checks.
Use /home/timo/.codex/plugins/cache/beyond10x/aep-drive/0.8.1/agents/implementor.md as role guidance subject to these explicit adaptations. The harness exposes generic agents; this is a charter-based dispatch, not an engine-driven run.

