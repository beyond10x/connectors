# Independent semantic reviewer A: stable-core pass

Worktree: /home/timo/.local/state/worktree/trees/b10x/connectors_v2/specs-review-a-20260909
Exact reviewed commit: eb0815961e6ffee54c50f91f37eff2bbe11811c0
Build: this worktree/target only, no shared CARGO_TARGET_DIR
Scratch: this worktree/.local/spec-completion-20260909
TMPDIR: this worktree/.local/tmp
Session: specs-review-a-20260909

The user explicitly requested sub-agents to accelerate the goal: all selected
specifications reviewed and stabilized before further runtime implementation.
You are a fresh reviewer, not an implementor and not a human approval gate.
Read AGENTS.md and docs/design.md. Acquire/renew/release your own managed worktree
lease. Tracked sources and planning are read-only; no new programs, Python,
runtime tests or full Rust build. You may write a report or bounded model probe
inputs under assigned scratch. ESS 0.20.0 is available at
/home/timo/beyond10x/connectors_v2/.local/toolchains/ess/0.20.0/bin/ess.
Use connectors for integrations, never fluxplane-plugin.

Start now on stable shared protocols: service v1alpha1/v1alpha2/compatibility,
delegation, auth (especially new read-refresh-once), operations/idempotency,
host management/persistence, catalog and their ESS declarations. Native log/
document and media/vocabulary/index workers are still finishing; do not spend
this pass reporting defects in their explicitly pending surfaces. A final
integration commit will follow so you can review those changes and finish your
whole-spec verdict without repeating stable-source review.

Check textual semantics and declared model coverage, not whether deliberately
unimplemented runtime behavior is already coded. Runtime conformance and backend
implementation obligations may remain when their semantics are decided and
claims are truthful. Distinguish those from actual unresolved selected semantics,
missing typed identities/relations that block specification completion, and
explicitly deferred/out-of-scope features. The selected runtime adapter set is
Kubernetes (including discovery), GitLab and SQL; authored broader contract/
adapter proposals still need truthful coherent semantics.

Read the original accepted source findings and relevant existing immutable
review records as context. New findings need a concrete reachable semantic
counterexample or contradictory clauses, precise file:line, consequence and
smallest coherent remedy. Do not relabel an explicitly stated implementation
obligation as a runtime defect, invent an invariant or pad the report with
speculative stylistic nits. Where a declaration/model accepts a counterexample,
say exactly what the tool proves and what is manual reasoning.

Send concrete blockers promptly. Write stable-core-review.md in scratch with
verdict needs-revision or no-blocking-findings-for-reviewed-scope, exact commit,
coverage, checks, and stable IDs SCA-01 onward. Include JSON findings with keys
file,line,category,severity (blocker|warning|note),verdict,origin,message;
place stable ID and engineering priority P0/P1/P2/P3 inside message.
An empty findings array is valid; do not invent findings for format reasons.
This initial pass is not a final whole-spec approval.
